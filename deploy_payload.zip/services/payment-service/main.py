import time
import uuid
import asyncio
from fastapi import FastAPI, HTTPException, Response
from pydantic import BaseModel
from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST

app = FastAPI(title="ResilienceOps-Payment-Service", version="1.0.0")

PAYMENT_COUNT = Counter("payments_processed_total", "Total Payments Processed", ["status", "gateway"])
PAYMENT_LATENCY = Histogram("payment_processing_duration_seconds", "Latency of payment gateway", buckets=[0.1, 0.25, 0.5, 1.0, 2.0, 5.0, 10.0])

CHAOS_STATE = {
    "network_delay": 0.0,
    "drop_rate": 0.0,
    "gateway_outage": False
}

class PaymentRequest(BaseModel):
    order_id: str
    amount: float
    currency: str = "USD"
    payment_method: str = "credit_card"

@app.get("/health")
async def health():
    if CHAOS_STATE["gateway_outage"]:
        raise HTTPException(status_code=503, detail="Payment upstream gateway unavailable")
    return {"status": "healthy", "service": "payment-service"}

@app.get("/metrics")
async def metrics():
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)

@app.post("/payments")
async def process_payment(req: PaymentRequest):
    start = time.time()
    
    if CHAOS_STATE["gateway_outage"]:
        PAYMENT_COUNT.labels(status="503_outage", gateway="stripe-sim").inc()
        raise HTTPException(status_code=503, detail="External Payment Gateway Connection Refused")
        
    if CHAOS_STATE["drop_rate"] > 0:
        import random
        if random.random() < CHAOS_STATE["drop_rate"]:
            PAYMENT_COUNT.labels(status="500_dropped", gateway="stripe-sim").inc()
            raise HTTPException(status_code=500, detail="Packet dropped / TLS handshake failed")
            
    # Simulate network transit or processing latency
    base_latency = 0.08 # 80ms standard
    delay = base_latency + CHAOS_STATE["network_delay"]
    await asyncio.sleep(delay)
    
    tx_id = f"tx-{uuid.uuid4().hex[:10]}"
    PAYMENT_COUNT.labels(status="success", gateway="stripe-sim").inc()
    PAYMENT_LATENCY.observe(time.time() - start)
    
    return {
        "transaction_id": tx_id,
        "order_id": req.order_id,
        "amount": req.amount,
        "currency": req.currency,
        "status": "settled",
        "processed_at": time.time()
    }

# ==========================================
# Chaos Injection Endpoints
# ==========================================

@app.post("/chaos/latency")
async def set_latency(seconds: float = 3.0):
    CHAOS_STATE["network_delay"] = seconds
    return {"status": "chaos_applied", "network_delay": seconds}

@app.post("/chaos/outage")
async def set_outage(enabled: bool = True):
    CHAOS_STATE["gateway_outage"] = enabled
    return {"status": "chaos_applied", "gateway_outage": enabled}

@app.post("/chaos/drop-rate")
async def set_drop_rate(rate: float = 0.4):
    CHAOS_STATE["drop_rate"] = rate
    return {"status": "chaos_applied", "drop_rate": rate}

@app.post("/chaos/reset")
async def reset_chaos():
    CHAOS_STATE["network_delay"] = 0.0
    CHAOS_STATE["drop_rate"] = 0.0
    CHAOS_STATE["gateway_outage"] = False
    return {"status": "clean", "message": "Payment service chaos cleared"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8002)
