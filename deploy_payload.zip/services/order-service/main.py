import os
import sys
import time
import uuid
import asyncio
from typing import List, Dict
from fastapi import FastAPI, HTTPException, Response
from pydantic import BaseModel
from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST

app = FastAPI(title="ResilienceOps-Order-Service", version="1.0.0")

# SRE Golden Signal Metrics
ORDER_COUNT = Counter("orders_processed_total", "Total Orders Processed", ["status"])
ORDER_LATENCY = Histogram("order_processing_duration_seconds", "Latency of order processing", buckets=[0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0])
MEMORY_LEAK_GAUGE = Gauge("active_memory_leak_bytes", "Memory leaked via chaos endpoint")

# In-memory storage & chaos state
ORDERS: Dict[str, dict] = {}
LEAKED_MEMORY_CHUNKS: List[bytes] = []
CHAOS_STATE = {
    "db_delay_seconds": 0.0,
    "error_injection_rate": 0.0,
    "is_corrupted": False
}

class CreateOrderRequest(BaseModel):
    item_id: str
    quantity: int
    amount: float
    user_id: str

@app.get("/health")
async def health():
    if CHAOS_STATE["is_corrupted"]:
        raise HTTPException(status_code=500, detail="Service internal state corrupted by chaos")
    return {"status": "healthy", "service": "order-service", "orders_count": len(ORDERS)}

@app.get("/metrics")
async def metrics():
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)

@app.post("/orders")
async def create_order(order_req: CreateOrderRequest):
    start = time.time()
    
    # Check chaos error injection
    if CHAOS_STATE["error_injection_rate"] > 0:
        import random
        if random.random() < CHAOS_STATE["error_injection_rate"]:
            ORDER_COUNT.labels(status="failed_chaos").inc()
            raise HTTPException(status_code=500, detail="Database connection pool timeout (injected fault)")
            
    # Check artificial DB delay
    if CHAOS_STATE["db_delay_seconds"] > 0:
        await asyncio.sleep(CHAOS_STATE["db_delay_seconds"])

    order_id = f"ord-{uuid.uuid4().hex[:8]}"
    order_data = {
        "order_id": order_id,
        "item_id": order_req.item_id,
        "quantity": order_req.quantity,
        "amount": order_req.amount,
        "user_id": order_req.user_id,
        "created_at": time.time(),
        "status": "confirmed"
    }
    ORDERS[order_id] = order_data
    duration = time.time() - start
    
    ORDER_COUNT.labels(status="success").inc()
    ORDER_LATENCY.observe(duration)
    return order_data

@app.get("/orders")
async def list_orders():
    if CHAOS_STATE["db_delay_seconds"] > 0:
        await asyncio.sleep(CHAOS_STATE["db_delay_seconds"])
    return list(ORDERS.values())[-20:]

# ==========================================
# Chaos Injection Endpoints (Red Team Targets)
# ==========================================

@app.post("/chaos/leak-memory")
async def chaos_leak_memory(mb: int = 50):
    """Allocates raw byte chunks in RAM to induce cgroup OOMKill (Exit 137)."""
    chunk = b"X" * (mb * 1024 * 1024)
    LEAKED_MEMORY_CHUNKS.append(chunk)
    total_bytes = sum(len(c) for c in LEAKED_MEMORY_CHUNKS)
    MEMORY_LEAK_GAUGE.set(total_bytes)
    return {
        "status": "memory_injected",
        "added_mb": mb,
        "total_leaked_mb": total_bytes // (1024 * 1024),
        "chunks_count": len(LEAKED_MEMORY_CHUNKS)
    }

@app.post("/chaos/cpu-burn")
async def chaos_cpu_burn(seconds: int = 15):
    """Spins CPU in tight mathematical loop, inducing CFS throttling and latency spikes."""
    async def burn():
        end_time = time.time() + seconds
        x = 0
        while time.time() < end_time:
            x += 1
            if x % 1000000 == 0:
                await asyncio.sleep(0.0001) # Yield to event loop
    asyncio.create_task(burn())
    return {"status": "cpu_burn_started", "duration_seconds": seconds}

@app.post("/chaos/db-latency")
async def chaos_db_latency(delay: float = 2.5):
    """Simulates PostgreSQL lock contention or network degradation."""
    CHAOS_STATE["db_delay_seconds"] = delay
    return {"status": "latency_injected", "db_delay_seconds": delay}

@app.post("/chaos/error-rate")
async def chaos_error_rate(rate: float = 0.5):
    """Simulates intermittent 500 error spikes."""
    CHAOS_STATE["error_injection_rate"] = rate
    return {"status": "error_rate_injected", "rate": rate}

@app.post("/chaos/crash")
async def chaos_crash():
    """Immediately kills process with exit code 1 to test K8s CrashLoopBackOff."""
    def kill_soon():
        time.sleep(0.5)
        sys.exit(1)
    import threading
    threading.Thread(target=kill_soon).start()
    return {"status": "terminating_process", "signal": "SIGKILL"}

@app.post("/chaos/reset")
async def chaos_reset():
    """Resets all injected chaos state back to baseline health."""
    global LEAKED_MEMORY_CHUNKS
    LEAKED_MEMORY_CHUNKS.clear()
    MEMORY_LEAK_GAUGE.set(0)
    CHAOS_STATE["db_delay_seconds"] = 0.0
    CHAOS_STATE["error_injection_rate"] = 0.0
    CHAOS_STATE["is_corrupted"] = False
    return {"status": "clean", "message": "All chaos vectors cleared"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
